
window.renderMyCDNComponent = function (container) {
  const element = document.createElement('div');
  element.innerHTML = `
    <h3 style="color: green;">🚀 Hello from Remote CDN Component!</h3>
    <p>This was loaded once from a remote script and reused.</p>
  `;
  element.style.border = '2px dashed green';
  element.style.padding = '15px';
  element.style.backgroundColor = '#f0fff0';
  container.appendChild(element);
};
