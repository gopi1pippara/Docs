
import React, { useState } from 'react';
import CDNComponentLoader from './CDNComponentLoader';

function App() {
  const [selected, setSelected] = useState('option1');

  return (
    <div style={{ padding: 30 }}>
      <h2>React CDN Component Loader</h2>

      <label>
        <input
          type="radio"
          name="group"
          value="option1"
          checked={selected === 'option1'}
          onChange={(e) => setSelected(e.target.value)}
        />
        Option 1
      </label>
      <br />

      <label>
        <input
          type="radio"
          name="group"
          value="cdn"
          checked={selected === 'cdn'}
          onChange={(e) => setSelected(e.target.value)}
        />
        Load Remote CDN Component
      </label>
      <br />

      <label>
        <input
          type="radio"
          name="group"
          value="option3"
          checked={selected === 'option3'}
          onChange={(e) => setSelected(e.target.value)}
        />
        Option 3
      </label>

      <div style={{ marginTop: 30 }}>
        <CDNComponentLoader
          cdnUrl={`${process.env.PUBLIC_URL}/my-remote-bundle.js`}
          globalRenderFn="renderMyCDNComponent"
          visible={selected === 'cdn'}
        />

        {selected === 'option1' && <div>You selected Option 1</div>}
        {selected === 'option3' && <div>You selected Option 3</div>}
      </div>
    </div>
  );
}

export default App;
