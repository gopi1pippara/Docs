
import React, { useEffect, useRef, useState } from 'react';

const CDNComponentLoader = ({ cdnUrl, globalRenderFn, visible }) => {
  const [isScriptLoaded, setScriptLoaded] = useState(false);
  const hasRenderedRef = useRef(false);
  const containerRef = useRef(null);

  useEffect(() => {
    if (!isScriptLoaded) {
      const script = document.createElement('script');
      script.src = cdnUrl;
      script.async = true;
      script.onload = () => setScriptLoaded(true);
      script.onerror = () => console.error(`Failed to load ${cdnUrl}`);
      document.body.appendChild(script);
    }
  }, [cdnUrl, isScriptLoaded]);

  useEffect(() => {
    if (
      isScriptLoaded &&
      !hasRenderedRef.current &&
      typeof window[globalRenderFn] === 'function'
    ) {
      window[globalRenderFn](containerRef.current);
      hasRenderedRef.current = true;
    }
  }, [isScriptLoaded, globalRenderFn]);

  return (
    <div
      ref={containerRef}
      style={{ display: visible ? 'block' : 'none' }}
    />
  );
};

export default CDNComponentLoader;
