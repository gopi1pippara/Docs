import React, { useEffect, useRef, useState } from "react";
import { loadScriptOnce } from "../utils/loadScriptOnce";

const jwtToken = "eyJhbGci..."; // Replace this with real JWT

const getChannelCode = () => "sampleChannel";
const getTrackingId = () => "sampleTracking";

const OmniD2D = ({ visible }) => {
  const [isScriptLoaded, setScriptLoaded] = useState(false);
  const containerRef = useRef(null);

  const cdnUrl = `https://qconfig.syfpos.com/d2dapply?token=${jwtToken}&channelCode=${getChannelCode()}&trackingId=${getTrackingId()}`;

  useEffect(() => {
    loadScriptOnce(cdnUrl)
      .then(() => {
        setScriptLoaded(true);
        if (window.GET_D2D_DATA) {
          window.GET_D2D_DATA({
            jwtToken,
            channelCode: getChannelCode(),
            trackingId: getTrackingId(),
          });
        }
      })
      .catch((err) => {
        console.error("Script load error:", err);
      });
  }, [cdnUrl]);

  return (
    <div
      id="d2d-apply-component"
      ref={containerRef}
      style={{ display: visible ? "block" : "none" }}
    >
      <h1>TEST</h1>
    </div>
  );
};

export default OmniD2D;
