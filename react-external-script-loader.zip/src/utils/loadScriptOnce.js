const loadedScripts = new Map();

export function loadScriptOnce(src) {
  if (loadedScripts.has(src)) {
    return loadedScripts.get(src); // Return existing Promise
  }

  const promise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = src;
    script.async = true;

    script.onload = () => {
      resolve();
    };

    script.onerror = (err) => {
      loadedScripts.delete(src); // Remove if failed
      reject(new Error(`Failed to load script: ${src}`));
    };

    document.body.appendChild(script);
  });

  loadedScripts.set(src, promise); // Store the Promise
  return promise;
}
